
var fs = require("fs");
 
// Asynchronous read 
fs.readFile('text.txt', function (err, data) {////////asynchro
   if (err) {
      return console.error(err);
   }
   console.log("Asynchronous read: " + data.toString());
});


var fs = require("fs");
 
// Synchronous read
var data = fs.readFileSync('text.txt'); ////sychro
console.log("Synchronous read: " + data.toString());




 
console.log("writing into existing file");
fs.writeFile('text.txt', 'Geeks For Geeks', function(err) {
   if (err) {
      return console.error(err);
   }

});




  
var data = "\nLearn Node.js";
  
// Append data to file ///////add data 
fs.appendFile('text.txt', data, 'utf8',
 
    // Callback function
    function(err) { 
        if (err) throw err;
 
        //  If no error
        console.log("Data is appended to file successfully.")
});